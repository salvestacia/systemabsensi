<?php
session_start();
include 'koneksi.php';
// Check if the user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}

// Retrieve earliest and latest dates from attendance
$startSql = "SELECT DATE(tgl_tap) AS startDate FROM absensi WHERE status = 'Tap in' ORDER BY tgl_tap ASC LIMIT 1";
$startDate = $koneksi->query($startSql)->fetch_assoc()['startDate'] ?? '';

$endSql = "SELECT DATE(tgl_tap) AS endDate FROM absensi WHERE status = 'Tap out' ORDER BY tgl_tap DESC LIMIT 1";
$endDate = $koneksi->query($endSql)->fetch_assoc()['endDate'] ?? '';

// Query to retrieve employee names
$sql_pegawai = "SELECT id_pegawai, nama FROM pegawai";
$result_pegawai = $koneksi->query($sql_pegawai);

$pegawai_options = $result_pegawai->num_rows > 0 ? '' : "<option value=''>Tidak ada data pegawai</option>";
while ($row = $result_pegawai->fetch_assoc()) {
    $pegawai_options .= "<option value='" . $row['id_pegawai'] . "'>" . $row['nama'] . "</option>";
}

$koneksi->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Payroll</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }
        form {
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="date"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        a {
            display: inline-block;
            text-decoration: none;
            padding: 10px 15px;
            margin-top: 20px;
            background-color: #28a745;
            color: white;
            border-radius: 4px;
            text-align: center;
        }
        a:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
<h1>Generate Payroll</h1>
<form action="http://localhost/systemabsensi/calculator.php" method="post">
    <label for="nama_karyawan">Nama Karyawan:</label>
    <select name="nama_karyawan" id="nama_karyawan" required>
        <?php echo $pegawai_options; ?>
    </select>
    <br>
    <label for="startDate">Start Date:</label>
    <input type="date" id="startDate" name="startDate" value="<?php echo $startDate; ?>" required>
    <br>
    <label for="endDate">End Date:</label>
    <input type="date" id="endDate" name="endDate" value="<?php echo $endDate; ?>" required>
    <br>
    <label for="keterangan">Keterangan:</label>
    <textarea name="keterangan" id="keterangan" rows="4"></textarea>
    <br>
    <button type="submit">Kalkulasi</button>
    <a href='http://localhost/systemabsensi/tabelgaji/read.php'>Kembali</a>
</form>
<br>
</body>
</html>
