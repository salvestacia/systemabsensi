<?php
session_start(); // Mulai session

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}

include "../koneksi.php";

if (isset($_POST['submit'])) {
    $id_user_query = "SELECT COALESCE(MAX(id_user), 0) + 1 AS next_id FROM pegawai";
    $id_user_result = $koneksi->query($id_user_query);
    $next_id_user = 1;

    if ($id_user_result && $id_user_result->num_rows > 0) {
        $row = $id_user_result->fetch_assoc();
        $next_id_user = $row['next_id'];
    }

    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $gaji_pokok = $_POST['gaji_pokok'];
    $kerja_1_bulan = $_POST['kerja_1_bulan'];
    $jam_kerja_1_hari = $_POST['jam_kerja_1_hari'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id_hak_akses = $_POST['id_hak_akses'];

    $query = "INSERT INTO pegawai (nama, alamat, tgl_lahir, gaji_pokok, 
    kerja_1_bulan, jam_kerja_1_hari, id_user, username, email, password, id_hak_akses, saldo_izin) 
    VALUES ('$nama', '$alamat', '$tgl_lahir', '$gaji_pokok', '$kerja_1_bulan', '$jam_kerja_1_hari', 
    '$next_id_user', '$username', '$email', '$password', '$id_hak_akses', 12)";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        echo "Data gagal ditambahkan!";
    } else {
        echo "Data berhasil ditambahkan!";
        header("Location: http://localhost/systemabsensi/tabelpegawai/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Karyawan</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center text-primary">Tambah Data Karyawan</h1>
    <form method="post" class="p-4 bg-light border rounded shadow-sm">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" name="nama" id="nama" required>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" name="alamat" id="alamat" required>
        </div>
        <div class="mb-3">
            <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
            <input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" required>
        </div>
        <div class="mb-3">
            <label for="gaji_pokok" class="form-label">Gaji Pokok</label>
            <input type="text" class="form-control" name="gaji_pokok" id="gaji_pokok" required>
        </div>
        <div class="mb-3">
            <label for="kerja_1_bulan" class="form-label">Kerja 1 Bulan</label>
            <input type="text" class="form-control" name="kerja_1_bulan" id="kerja_1_bulan" required>
        </div>
        <div class="mb-3">
            <label for="jam_kerja_1_hari" class="form-label">Jam Kerja 1 Hari</label>
            <input type="text" class="form-control" name="jam_kerja_1_hari" id="jam_kerja_1_hari" required>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" name="username" id="username" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" required>
        </div>
        <div class="mb-3">
            <label for="id_hak_akses" class="form-label">Hak Akses</label>
            <select class="form-select" name="id_hak_akses" id="id_hak_akses" required>
                <option value="1">Karyawan</option>
                <option value="2">Admin</option>
            </select>
        </div>
        <div class="d-flex justify-content-between">
            <button type="submit" name="submit" class="btn btn-primary">Tambah</button>
            <a href="http://localhost/systemabsensi/tabelpegawai/read.php" class="btn btn-secondary">Kembali</a>
            <a href="http://localhost/systemabsensi/logout.php" class="btn btn-danger">Logout</a>
        </div>
    </form>
</div>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
