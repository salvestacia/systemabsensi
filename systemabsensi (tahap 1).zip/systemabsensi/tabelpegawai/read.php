<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header("Location: ../index.php");
    exit();
}

include "../koneksi.php";

$query = "SELECT * FROM pegawai";
$result = mysqli_query($koneksi, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabel Pegawai</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-primary">Tabel Pegawai</h1>
    <div class="mb-3">
        <a href="http://localhost/systemabsensi/tabelpegawai/create.php" class="btn btn-primary">Tambah</a>
        <a href="http://localhost/systemabsensi/halamanBeranda.php" class="btn btn-secondary">Kembali</a>
    </div>
    <table class="table table-bordered table-striped">
        <thead class="table-primary">
        <tr>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Tanggal Lahir</th>
            <th>Saldo Izin</th>
            <th>Jam Kerja 1 Hari</th>
            <th>Kerja 1 Bulan</th>
            <th>Gaji Pokok</th>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <th>Hak Akses</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['nama']) . "</td>
                        <td>" . htmlspecialchars($row['alamat']) . "</td>
                        <td>" . htmlspecialchars($row['tgl_lahir']) . "</td>
                        <td>" . htmlspecialchars($row['saldo_izin']) . "</td>
                        <td>" . htmlspecialchars($row['jam_kerja_1_hari']) . "</td>
                        <td>" . htmlspecialchars($row['kerja_1_bulan']) . "</td>
                        <td>" . htmlspecialchars($row['gaji_pokok']) . "</td>
                        <td>" . htmlspecialchars($row['username']) . "</td>
                        <td>" . htmlspecialchars($row['email']) . "</td>
                        <td>" . htmlspecialchars($row['password']) . "</td>
                        <td>" . htmlspecialchars($row['id_hak_akses']) . "</td>
                        <td>
                            <a href='http://localhost/systemabsensi/tabelpegawai/update.php?id=" . htmlspecialchars($row['id_pegawai']) . "' class='btn btn-warning btn-sm'>Edit</a>
                        </td>
                    </tr>";
            }
            mysqli_free_result($result); // Bebaskan hasil query
        } else {
            echo "<tr><td colspan='12' class='text-center'>Data tidak ditemukan</td></tr>";
        }
        mysqli_close($koneksi); // Tutup koneksi
        ?>
        </tbody>
    </table>
</div>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
