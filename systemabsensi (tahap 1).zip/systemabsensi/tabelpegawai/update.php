<?php
session_start(); // Mulai session

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['logged_in'])) {
    // Jika belum login, redirect kembali ke halaman login atau halaman lain
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}
?>

<?php
include "../koneksi.php";
$id = $_GET['id'];
$query = "SELECT * FROM pegawai WHERE id_pegawai= '$id'";
$result = mysqli_query($koneksi, $query);
if(!$result){
    echo "Query gagal!";
}
else{
    $data = mysqli_fetch_assoc($result);
}
if(isset($_POST["submit"])){
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $saldo_izin = $_POST['saldo_izin'];
    $gaji_pokok = $_POST['gaji_pokok'];
    $kerja_1_bulan = $_POST['kerja_1_bulan'];
    $jam_kerja_1_hari = $_POST['jam_kerja_1_hari'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $id_hak_akses = $_POST['id_hak_akses'];
    $query = "UPDATE pegawai SET saldo_izin = '$saldo_izin', nama ='$nama', alamat = '$alamat', tgl_lahir = '$tgl_lahir', gaji_pokok = '$gaji_pokok', kerja_1_bulan = '$kerja_1_bulan', 
    jam_kerja_1_hari = '$jam_kerja_1_hari', username = '$username', email = '$email', password = '$password', id_hak_akses = '$id_hak_akses' WHERE id_pegawai ='$id' ";
    $result = mysqli_query($koneksi, $query);
    if(!$result){
        echo "Data gagal diubah!";
    }
    else{
        echo "Data berhasil diubah!";
        header("Location: http://localhost/systemabsensi/tabelpegawai/read.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Data Karyawan</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center text-primary mb-4">Ubah Data Karyawan</h1>
    <form method="post" class="p-4 bg-light border rounded shadow-sm">
        <input type="hidden" name="id" value="<?php echo $data['id_pegawai']; ?>">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" class="form-control" name="nama" id="nama" value="<?php echo $data['nama']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo $data['alamat']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="tgl_lahir" class="form-label">Tanggal Lahir</label>
            <input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" value="<?php echo $data['tgl_lahir']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="saldo_izin" class="form-label">Saldo Izin</label>
            <input type="text" class="form-control" name="saldo_izin" id="saldo_izin" value="<?php echo $data['saldo_izin']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="gaji_pokok" class="form-label">Gaji Pokok</label>
            <input type="text" class="form-control" name="gaji_pokok" id="gaji_pokok" value="<?php echo $data['gaji_pokok']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="kerja_1_bulan" class="form-label">Kerja 1 Bulan</label>
            <input type="text" class="form-control" name="kerja_1_bulan" id="kerja_1_bulan" value="<?php echo $data['kerja_1_bulan']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="jam_kerja_1_hari" class="form-label">Jam Kerja 1 Hari</label>
            <input type="text" class="form-control" name="jam_kerja_1_hari" id="jam_kerja_1_hari" value="<?php echo $data['jam_kerja_1_hari']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" class="form-control" name="username" id="username" value="<?php echo $data['username']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email" id="email" value="<?php echo $data['email']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" name="password" id="password" value="<?php echo $data['password']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="id_hak_akses" class="form-label">Hak Akses</label>
            <select class="form-select" name="id_hak_akses" id="id_hak_akses" required>
                <option value="1" <?php if($data['id_hak_akses'] == 1) echo 'selected'; ?>>Karyawan</option>
                <option value="2" <?php if($data['id_hak_akses'] == 2) echo 'selected'; ?>>Admin</option>
            </select>
        </div>
        <div class="d-flex justify-content-between">
            <button type="submit" name="submit" class="btn btn-success">Ubah</button>
            <a href="http://localhost/systemabsensi/tabelpegawai/read.php" class="btn btn-secondary">Kembali</a>
        </div>
        <div class="mt-3">
        <a href="http://localhost/systemabsensi/logout.php" class="btn btn-danger">Logout</a>
        </div>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
