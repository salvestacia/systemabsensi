<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "absensss";

$koneksi = new mysqli($host, $user, $pass, $db);

if ($koneksi->connect_error) {
    die("Koneksi Gagal: ". $koneksi->connect_erorr);
}