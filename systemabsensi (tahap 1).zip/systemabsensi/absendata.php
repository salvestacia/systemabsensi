<?php
session_start();
include 'koneksi.php'; 

if (!isset($_SESSION['logged_in'])) {
    header('Location: http://localhost/systemabsensi/index.php');
    exit;
}

$sql = "SELECT 
            absensi.id, 
            pegawai.nama, 
            DATE(absensi.tgl_tap) AS date, 
            TIME(absensi.tgl_tap) AS time, 
            absensi.status 
        FROM absensi
        JOIN pegawai ON absensi.id_pegawai = pegawai.id_pegawai";

$result = $koneksi->query($sql);

$koneksi->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>absendata</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        #back {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #007bff; 
            color: white;
            border-radius: 5px;
            margin-top: 10px;
        }

        #back:hover {
            background-color: #0056b3; 
        }

        #logout {
            display: inline-block;
            padding: 8px 16px;
            text-decoration: none;
            background-color: #dc3545; 
            color: white;
            border-radius: 5px;
            margin-top: 10px;
        }

        #logout:hover {
            background-color: #c82333; 
        }
    </style>
</head>
<body>
    <h1>Rekap Absensi</h1>
    <a href= "http://localhost/systemabsensi/halamanBeranda.php" id="back">Kembali</a>
    <a href= "http://localhost/systemabsensi/logout.php" id="logout">Logout</a>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["nama"] . "</td>";
                    echo "<td>" . $row["date"] . "</td>";
                    echo "<td>" . $row["time"] . "</td>";
                    echo "<td>" . $row["status"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>