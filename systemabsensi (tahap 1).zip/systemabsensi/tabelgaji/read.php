<?php
session_start();
include "../koneksi.php";

$query = "SELECT 
        pegawai.*, payroll.*
    FROM 
        pegawai
    INNER JOIN 
        payroll
    ON 
        pegawai.id_pegawai = payroll.id_pegawai";

$result = mysqli_query($koneksi, $query);

if (!$result) {
    echo "Query Gagal: " . mysqli_error($koneksi);
} else {
    echo "<h1>Tabel Gaji</h1>";
    echo "<a href='http://localhost/systemabsensi/generalpayroll.php'>Payroll</a>";
    echo "<a href='http://localhost/systemabsensi/halamanBeranda.php'>Kembali</a>";

    // Menambahkan CSS
    echo "<style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-top: 20px;
        }
        a {
            display: inline-block;
            margin: 10px;
            text-decoration: none;
            padding: 8px 15px;
            background-color: #007BFF;
            color: white;
            border-radius: 5px;
        }
        a:hover {
            background-color: #0056b3;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        td a {
            padding: 5px 10px;
            background-color: #FF5733;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        td a:hover {
            background-color: #c04e2d;
        }
    </style>";

    echo "<table>
        <tr>
            <th>Nama</th>
            <th>Periode Awal</th>
            <th>Periode Akhir</th>
            <th>Jam Kerja 1 Bulan</th>
            <th>Gaji</th>
            <th>Aksi</th>
        </tr>";

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
                <td>" . $row['nama'] . "</td>
                <td>" . $row['periode_awal'] . "</td>
                <td>" . $row['periode_akhir'] . "</td>
                <td>" . $row['jam_kerja_1_bulan'] . "</td>
                <td>" . $row['gaji'] . "</td>
                <td>
                    <a href='http://localhost/systemabsensi/tabelgaji/delete.php?id=".$row['id']."'>Hapus</a>
                </td>
            </tr>";
    }

    mysqli_free_result($result); // Bebaskan hasil query
    mysqli_close($koneksi); // Tutup koneksi
}
?>
