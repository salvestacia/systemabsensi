<?php
include 'koneksi.php';
session_start(); // Mulai session
// Check if the user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}

// Fetch user role
$id_user = $_SESSION['id_user'];
$sql_role = "SELECT id_hak_akses FROM pegawai WHERE id_user = ?";
$stmt_role = $koneksi->prepare($sql_role);
$stmt_role->bind_param("i", $id_user);
$stmt_role->execute();
$result_role = $stmt_role->get_result();
$user = $result_role->fetch_assoc();
$hak_akses = $user['id_hak_akses'];

// Fetch allowed features for the user role
$sql_access = "SELECT link, fitur FROM hak_akses WHERE id_hak_akses = ?";
$stmt_access = $koneksi->prepare($sql_access);
$stmt_access->bind_param("i", $hak_akses);
$stmt_access->execute();
$result_access = $stmt_access->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9f9;
        color: #333;
        display: flex;
        height: 100vh;
    }

    .sidebar {
        width: 250px;
        background-color: #2c3e50;
        color: white;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .sidebar h2 {
        font-size: 1.5rem;
        margin-bottom: 20px;
        text-align: center;
        border-bottom: 2px solid white;
        padding-bottom: 10px;
    }

    .sidebar ul {
        list-style: none;
        padding: 0;
    }

    .sidebar ul li {
        margin-bottom: 10px;
    }

    .sidebar ul li a {
        display: block;
        padding: 10px 15px;
        text-decoration: none;
        color: white;
        background-color: #3498db;
        border-radius: 5px;
        transition: background-color 0.2s ease-in-out;
        text-align: center;
    }

    .sidebar ul li a:hover {
        background-color: #2980b9;
    }

    .content {
        flex: 1;
        padding: 20px;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #ffffff;
    }

    .content h1 {
        font-size: 2rem;
        color: #2c3e50;
    }

    #logout {
    display: inline-block;
    padding: 8px 16px;
    text-decoration: none;
    background-color: #dc3545;
    color: white;
    border-radius: 5px;
    margin-top: 10px;
    position: absolute;
    top: 10px;
    right: 10px;
    }

    #logout:hover {
        background-color: #c82333;
    }

</style>

</head>
<body>
<a href= "http://localhost/systemabsensi/logout.php" id="logout">Logout</a>
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
            <?php while($row = $result_access->fetch_assoc()): ?>
            <li>
                <a href='<?php echo $row['link']; ?>'><?php echo $row['fitur']; ?></a>
            </li>
            <?php endwhile; ?>
        </ul>
    </div>
    <div class="content">
        <h1>Selamat Datang di Sistem Informasi PT Standardpen Industries</h1>
    </div>
</body>

</html>

<?php
$stmt_role->close();
$stmt_access->close();
$koneksi->close();
?>