<?php
session_start();
include 'koneksi.php'; 
date_default_timezone_set('Asia/Bangkok');
if (!isset($_SESSION['logged_in'])) {
    header('Location: http://localhost/systemabsensi/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_pegawai = $_SESSION['id_pegawai'];
    $status = $_POST['status'];
    $tgl_tap = date('Y-m-d H:i:s');

    $sql = "INSERT INTO absensi (id_pegawai, tgl_tap, status) VALUES ('$id_pegawai', '$tgl_tap', '$status')";

    if ($koneksi->query($sql) === TRUE) {
        $message = "Successfully recorded $status at $tgl_tap";
    } else {
        $message = "Error: " . $sql . "<br>" . $koneksi->error;
    }
}
$koneksi->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }
        h1 {
            color: #333;
        }
        .logout {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        button, a {
            padding: 15px 30px;
            margin: 10px;
            font-size: 16px;
            cursor: pointer;
            border: none;
            border-radius: 5px;
        }
        .tap-in {
            background-color: #4CAF50;
            color: white;
            margin-bottom: 25px;
        }
        .tap-in:hover{
            background-color: #45A049;
        }

        .tap-out {
            background-color: #f44336;
            color: white;
            margin-bottom: 25px;
        }
        .tap-out:hover{
            background-color: #c82333;
        }

        a{
            background-color: blue;
            color: white;
            text-decoration: none;
            display: inline-block; /* Ensures proper spacing */
            margin-bottom: 20px; /* Adds spacing below the "Kembali" button */
            padding: 15px 30px;
            font-size: 16px;
            border-radius: 5px;
        }
        a:hover{
            background-color: #0069d9;
        }

        #statusMessage {
            margin-top: 20px;
            font-size: 18px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="logout">
        <form action="http://localhost/systemabsensi/logout.php" method="post">
            <button type="submit">Logout</button>
        </form>
    </div>
    <h1>Attendance System</h1>
    <div id="clock" style="font-size: 24px; margin-bottom: 20px;"></div>
    <div id="statusMessage"><?php echo isset($message) ? $message : ''; ?></div>
    <a href="http://localhost/systemabsensi/halamanBeranda.php" class="button">Kembali</a>
    <form method="POST">
        <button class="tap-in" name="status" value="Tap in">Tap In</button>
        <button class="tap-out" name="status" value="Tap out">Tap Out</button>
    </form>
    <script>
         function updateClock() {
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var seconds = now.getSeconds();
            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // the hour '0' should be '12'
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;
            var strTime = hours + ':' + minutes + ':' + seconds + ' ' + ampm;
            document.getElementById('clock').innerHTML = strTime;
        }
        setInterval(updateClock, 1000);
        updateClock(); // initial call to display the clock immediately
    </script>
</body>
</html>