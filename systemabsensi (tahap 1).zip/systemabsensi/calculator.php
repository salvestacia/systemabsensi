<?php
session_start();
include 'koneksi.php';

// Check if the user is logged in
if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}

// Function to calculate salary
function calculateSalary($totalJamKerja, $jamKerjaIdeal, $gajiPokok) {
    return ($totalJamKerja / $jamKerjaIdeal) * $gajiPokok;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $information = $_POST['keterangan'];
    $employeeId = $_POST['nama_karyawan'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];

    // Query to get employee details
    $sql = "SELECT id_pegawai, nama AS name, gaji_pokok AS salary, kerja_1_bulan AS working_days, jam_kerja_1_hari AS working_hours 
            FROM pegawai WHERE id_pegawai = ?";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('s', $employeeId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $employeeName = $row['name'];
        $id_pegawai = $row['id_pegawai'];
        $salary = $row['salary'];
        $totalWorkingDays = $row['working_days'];
        $dailyWorkingHours = $row['working_hours'];
    } else {
        echo "Data pegawai tidak ditemukan.";
        exit;
    }

    // Calculate ideal working hours
    $jamKerjaIdeal = $totalWorkingDays * $dailyWorkingHours;

    // Query to calculate total working hours
    $sql = "SELECT SUM(TIMESTAMPDIFF(SECOND, min_tap, max_tap)) AS totalSeconds
        FROM (
            SELECT 
                MIN(tgl_tap) AS min_tap, 
                MAX(tgl_tap) AS max_tap
            FROM absensi 
            WHERE id_pegawai = ? 
              AND DATE(tgl_tap) BETWEEN ? AND ?
              AND status IN ('Tap in', 'Tap out')
            GROUP BY DATE(tgl_tap)
        ) AS daily";

    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param('sss', $employeeId, $startDate, $endDate);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $totalSeconds = $row['totalSeconds'];
        $totalJamKerja = $totalSeconds / 3600; // Convert seconds to hours
    } else {
        echo "Data kehadiran tidak ditemukan.";
        exit;
    }

    // Calculate salary using the function from payroll.php
    $totalWages = calculateSalary($totalJamKerja, $jamKerjaIdeal, $salary);

    // Insert salary data into the payroll table
    $insertSql = "INSERT INTO payroll (id_pegawai, periode_awal, periode_akhir, jam_kerja_1_bulan, gaji, keterangan) 
                  VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $koneksi->prepare($insertSql);
    $stmt->bind_param('ssssds', $id_pegawai, $startDate, $endDate, $totalJamKerja, $totalWages, $information);
    
    if ($stmt->execute()) {
        echo "Data gaji berhasil dimasukkan ke dalam tabel payroll.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $koneksi->close();

    header('Location: http://localhost/systemabsensi/tabelgaji/read.php');
    exit;
}
?>
