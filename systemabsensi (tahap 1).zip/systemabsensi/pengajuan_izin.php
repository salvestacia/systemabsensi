<?php
include 'koneksi.php';
session_start();

if (!isset($_SESSION['logged_in'])) {
    header("Location: http://localhost/systemabsensi/index.php");
    exit();
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer-master/src/Exception.php';
require './PHPMailer-master/src/PHPMailer.php';
require './PHPMailer-master/src/SMTP.php';

$id_pegawai = $_SESSION['id_pegawai'];
$nama_pegawai = $_SESSION['nama'];

// Ambil saldo_izin dan gaji pegawai
$sql = "SELECT p.saldo_izin, COALESCE(pr.gaji, 0) AS gaji 
        FROM pegawai p 
        LEFT JOIN payroll pr ON p.id_pegawai = pr.id_pegawai 
        WHERE p.id_pegawai = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $id_pegawai);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

$saldo_izin = $data['saldo_izin'];
$gaji = $data['gaji'];

$stmt->close();

// Periksa apakah saldo izin dan saldo gaji sama-sama 0
if ($saldo_izin <= 0 && $gaji <= 0) {
    echo "<script>
        alert('Tidak ada saldo izin maupun saldo gaji yang tersisa. Anda tidak dapat mengajukan izin.');
        window.location.href = 'http://localhost/systemabsensi/halamanBeranda.php';
    </script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $periode_awal = $_POST['periode_awal'];
    $periode_akhir = $_POST['periode_akhir'];
    $alasan_izin = $_POST['alasan_izin'];

    // Hitung durasi izin
    $datetime1 = new DateTime($periode_awal);
    $datetime2 = new DateTime($periode_akhir);
    $interval = $datetime1->diff($datetime2);
    $durasi_izin = $interval->days + 1;

    if ($saldo_izin >= $durasi_izin) {
        // Potong saldo izin
        $saldo_izin -= $durasi_izin;

        $sql_update = "UPDATE pegawai SET saldo_izin = ? WHERE id_pegawai = ?";
        $stmt = $koneksi->prepare($sql_update);
        $stmt->bind_param("ii", $saldo_izin, $id_pegawai);
        $stmt->execute();
        $stmt->close();
    } else {
        // Potong gaji
        $potongan_gaji = $durasi_izin * 100000;
        $gaji -= $potongan_gaji;

        $sql_update = "UPDATE payroll SET gaji = ? WHERE id_pegawai = ?";
        $stmt = $koneksi->prepare($sql_update);
        $stmt->bind_param("ii", $gaji, $id_pegawai);
        $stmt->execute();
        $stmt->close();
    }

    // Masukkan data izin ke database
    $sql = "INSERT INTO izin (id_pegawai, periode_awal, periode_akhir, alasan_izin) VALUES (?, ?, ?, ?)";
    $stmt = $koneksi->prepare($sql);
    $stmt->bind_param("isss", $id_pegawai, $periode_awal, $periode_akhir, $alasan_izin);

    if ($stmt->execute()) {
        // Kirim email notifikasi
        $mail = new PHPMailer();

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'rachelamanda1607@gmail.com';
            $mail->Password = 'jqlsodujdhjiohkc';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Abaikan verify SSL
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $mail->setFrom('rachelamanda1607@gmail.com', 'PT Standardpen Industries');
            $mail->addAddress('rachelamanda1607@gmail.com');

            $mail->isHTML(true);
            $mail->Subject = 'Notifikasi Izin Baru';
            $mail->Body = "$nama_pegawai telah mengajukan izin.<br>
                          Periode: $periode_awal hingga $periode_akhir<br>
                          Alasan: $alasan_izin.";

            $mail->send();
        } catch (Exception $e) {
            error_log("Email gagal dikirim. Error: {$mail->ErrorInfo}");
        }

        echo "<script>
        alert('Pengajuan izin berhasil dikirim!');
        window.location.href='http://localhost/systemabsensi/pengajuan_izin.php';
            </script>";
    } else {
        echo "Gagal mengajukan izin.";
    }

    $stmt->close();
    $koneksi->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengajuan Izin</title>
    <style>
        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9998;
        }

        #loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            text-align: center;
            color: white;
            font-size: 24px;
            padding-top: 20%;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 500px;
            margin: 0 auto;
            border: 2px solid black;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="date"], 
        select, 
        textarea {
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
        }

        textarea {
            height: 100px;
        }

        button[type="submit"], 
        a.button {
            padding: 8px 16px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            display: inline-block;
        }

        button[type="submit"]:hover, 
        a.button:hover {
            background-color: #0056b3;
        }

        /* Centering the text horizontally and vertically */
        .centered-text {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            margin-bottom: 20px; /* Optional: adds space between paragraphs */
        }

        .centered-text p {
            font-size: 1.2rem;
            color: #343a40;
            margin: 5px 0;
        }


    </style>
    <script>
        function showLoading() {
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('loading').style.display = 'block';
        }
    </script>
</head>
<body>
    <div id="overlay"></div>
    <div id="loading">Processing your request, please wait...</div>
    <h1>Form Pengajuan Izin</h1>

    <div class="centered-text">
    <p>Saldo Izin Tersisa: <strong><?= $saldo_izin; ?> hari</strong></p>
    <p>Gaji Saat Ini: <strong>Rp<?= number_format($gaji, 0, ',', '.'); ?></strong></p>
    </div>
    
    <form action="" method="post" onsubmit="showLoading()">
        <label for="periode_awal">Periode Awal:</label>
        <input type="date" name="periode_awal" id="periode_awal" required><br>

        <label for="periode_akhir">Periode Akhir:</label>
        <input type="date" name="periode_akhir" id="periode_akhir" required><br>

        <label for="alasan_izin">Alasan Izin:</label>
        <textarea name="alasan_izin" id="alasan_izin" required></textarea><br>

        <button type="submit">Kirim</button>
        <a href="http://localhost/systemabsensi/halamanBeranda.php" class="button">Back</a>
    </form>
</body>
</html>
