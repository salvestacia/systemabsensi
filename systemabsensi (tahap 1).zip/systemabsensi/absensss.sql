/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE TABLE `absensi` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(5) DEFAULT NULL,
  `tgl_tap` datetime DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `hak_akses` (
  `id_hak_akses` int(10) NOT NULL,
  `nama_hak_akses` varchar(50) DEFAULT NULL,
  `fitur` varchar(50) DEFAULT NULL,
  `link` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `izin` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(5) DEFAULT NULL,
  `periode_awal` date DEFAULT NULL,
  `periode_akhir` date DEFAULT NULL,
  `alasan_izin` varchar(100) DEFAULT NULL,
  `status` enum('approve','reject') DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pegawai` (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `payroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_pegawai` int(5) DEFAULT NULL,
  `periode_awal` date DEFAULT NULL,
  `periode_akhir` date DEFAULT NULL,
  `jam_kerja_1_bulan` int(20) DEFAULT NULL,
  `gaji` int(20) DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_pegawai` (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `pegawai` (
  `id_pegawai` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `tgl_lahir` date DEFAULT NULL,
  `gaji_pokok` int(20) DEFAULT NULL,
  `kerja_1_bulan` int(5) DEFAULT NULL,
  `jam_kerja_1_hari` int(5) DEFAULT NULL,
  `saldo_izin` int(5) DEFAULT NULL,
  `id_user` int(5) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `id_hak_akses` int(5) DEFAULT NULL,
  PRIMARY KEY (`id_pegawai`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `absensi` (`id`, `id_pegawai`, `tgl_tap`, `status`) VALUES
(137, 17, '2024-11-18 08:00:00', 'Tap in'),
(138, 17, '2024-11-18 17:00:00', 'Tap out'),
(139, 17, '2024-11-19 08:00:00', 'Tap in'),
(140, 17, '2024-11-19 17:00:00', 'Tap out'),
(141, 17, '2024-11-20 08:00:00', 'Tap in'),
(142, 17, '2024-11-20 17:00:00', 'Tap out'),
(143, 17, '2024-11-21 08:00:00', 'Tap in'),
(144, 17, '2024-11-21 17:00:00', 'Tap out'),
(145, 17, '2024-11-22 08:00:00', 'Tap in'),
(146, 17, '2024-11-22 17:00:00', 'Tap out'),
(147, 17, '2024-11-23 08:00:00', 'Tap in'),
(148, 17, '2024-11-23 17:00:00', 'Tap out'),
(149, 17, '2024-11-24 08:00:00', 'Tap in'),
(150, 17, '2024-11-24 17:00:00', 'Tap out'),
(151, 17, '2024-11-25 08:00:00', 'Tap in'),
(152, 17, '2024-11-25 17:00:00', 'Tap out'),
(153, 17, '2024-11-26 08:00:00', 'Tap in'),
(154, 17, '2024-11-26 17:00:00', 'Tap out'),
(155, 17, '2024-11-27 08:00:00', 'Tap in'),
(156, 17, '2024-11-27 17:00:00', 'Tap out'),
(157, 17, '2024-12-04 08:05:01', 'Tap in'),
(158, 17, '2024-12-04 16:05:03', 'Tap out');

INSERT INTO `hak_akses` (`id_hak_akses`, `nama_hak_akses`, `fitur`, `link`) VALUES
(2, 'Admin', 'Data Pegawai', 'http://localhost/systemabsensi/tabelpegawai/read.php');
INSERT INTO `hak_akses` (`id_hak_akses`, `nama_hak_akses`, `fitur`, `link`) VALUES
(2, 'Admin', 'Rekap Absensi', 'http://localhost/systemabsensi/absendata.php');
INSERT INTO `hak_akses` (`id_hak_akses`, `nama_hak_akses`, `fitur`, `link`) VALUES
(2, 'Admin', 'Data Gaji', 'http://localhost/systemabsensi/tabelgaji/read.php');
INSERT INTO `hak_akses` (`id_hak_akses`, `nama_hak_akses`, `fitur`, `link`) VALUES
(2, 'Admin', 'Lakukan Absen', 'http://localhost/systemabsensi/lakukanAbsen.php'),
(2, 'Admin', 'Manajemen Izin', 'http://localhost/systemabsensi/manajemen_izin.php'),
(1, 'Pegawai', 'Lakukan Absen', 'http://localhost/systemabsensi/lakukanAbsen.php'),
(1, 'Pegawai', 'Pengajuan Izin', 'http://localhost/systemabsensi/pengajuan_izin.php'),
(2, 'Admin', 'Profile', 'http://localhost/systemabsensi/profile.php'),
(1, 'Pegawai', 'Profile', 'http://localhost/systemabsensi/profile.php');

INSERT INTO `izin` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `alasan_izin`, `status`) VALUES
(6, 17, '2024-11-25', '2024-11-26', 'sakit demam', 'approve');
INSERT INTO `izin` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `alasan_izin`, `status`) VALUES
(7, 17, '2024-11-25', '2024-11-26', 'demam kak', 'approve');
INSERT INTO `izin` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `alasan_izin`, `status`) VALUES
(8, 17, '2024-11-25', '2024-11-26', 'pelatihan ', 'reject');
INSERT INTO `izin` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `alasan_izin`, `status`) VALUES
(9, 17, '2024-11-25', '2024-11-27', 'gaji', 'approve'),
(10, 17, '2024-11-25', '2024-11-27', 'liburan', 'reject'),
(11, 17, '2024-11-25', '2024-11-27', 'sakit pak', 'approve'),
(12, 17, '2024-11-25', '2024-11-27', 'sakit lagi', 'reject'),
(13, 17, '2024-11-25', '2024-11-27', 'izin kak', 'approve'),
(14, 17, '2024-11-25', '2024-11-27', 'tesss', 'approve'),
(15, 18, '2024-12-09', '2024-12-10', 'izin jenguk papa mama', 'approve'),
(16, 19, '2024-12-09', '2024-12-10', 'izin ke klinik', 'reject'),
(19, 18, '2024-12-09', '2024-12-10', 'izin menjenguk adik', 'approve');

INSERT INTO `payroll` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `jam_kerja_1_bulan`, `gaji`, `keterangan`) VALUES
(16, 17, '2024-11-18', '2024-12-04', 98, 3062517, 'gaji');
INSERT INTO `payroll` (`id`, `id_pegawai`, `periode_awal`, `periode_akhir`, `jam_kerja_1_bulan`, `gaji`, `keterangan`) VALUES
(17, 17, '2024-11-18', '2024-12-04', 98, 3062517, 'gaji achel 11/18/2024 - 12/04/2024');


INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `tgl_lahir`, `gaji_pokok`, `kerja_1_bulan`, `jam_kerja_1_hari`, `saldo_izin`, `id_user`, `username`, `email`, `password`, `id_hak_akses`) VALUES
(17, 'Rachelya Amanda', 'Sunter', '2003-12-07', 5000000, 20, 8, 12, 1, 'achel', 'rachelamanda1607@gmail.com', '123456', 2);
INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `tgl_lahir`, `gaji_pokok`, `kerja_1_bulan`, `jam_kerja_1_hari`, `saldo_izin`, `id_user`, `username`, `email`, `password`, `id_hak_akses`) VALUES
(18, 'Darren Christian', 'Kelapa Gading', '2004-12-06', 5000000, 20, 8, 4, 2, 'darren', 'darrenchrist2@gmail.com', '123456', 1);
INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `tgl_lahir`, `gaji_pokok`, `kerja_1_bulan`, `jam_kerja_1_hari`, `saldo_izin`, `id_user`, `username`, `email`, `password`, `id_hak_akses`) VALUES
(19, 'Hanlouis', 'Bassura', '2004-04-10', 5000000, 20, 8, 10, 3, 'han', '2022105358@student.kalbis.ac.id', '123456', 1);
INSERT INTO `pegawai` (`id_pegawai`, `nama`, `alamat`, `tgl_lahir`, `gaji_pokok`, `kerja_1_bulan`, `jam_kerja_1_hari`, `saldo_izin`, `id_user`, `username`, `email`, `password`, `id_hak_akses`) VALUES
(20, 'Raymond Johan', 'Bintaro', '2004-01-01', 5000000, 20, 8, 12, 4, 'raymond', '2022105380@student.kalbis.ac.id', '123456', 1);


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;