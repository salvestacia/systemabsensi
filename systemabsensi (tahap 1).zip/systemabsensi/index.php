<?php
include 'koneksi.php';

session_start(); // Mulai session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form login
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    // Query untuk mencari user dengan username dan password yang sesuai
    $query = "SELECT id_user, id_pegawai, id_hak_akses, email, nama FROM pegawai WHERE username=? AND password=?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param('ss', $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        // Jika data ditemukan, simpan informasi pengguna dalam session
        $stmt->bind_result($id_user, $id_pegawai, $hak_akses, $email, $nama);
        $stmt->fetch();

        $_SESSION['username'] = $username; //session membawa data username
        $_SESSION['logged_in'] = true; 
        $_SESSION['id_pegawai'] = $id_pegawai; //session membawa data id_pegawai
        $_SESSION['id_user'] = $id_user; //session membawa data id user
        $_SESSION['nama'] = $nama; //session membawa data nama pegawai

        // Redirect ke halaman utama
        header("Location: http://localhost/systemabsensi/halamanBeranda.php");
        exit(); // Pastikan untuk menghentikan eksekusi kode setelah melakukan redirect
    } else {
        // Jika data tidak ditemukan, tampilkan pesan error atau redirect kembali ke halaman login
        echo "Username atau password salah.";
    }

    $stmt->close();
    mysqli_close($koneksi);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .error-message {
            margin-top: 10px;
        }
        #register {
            cursor: pointer;
            color: #007bff;
            font-size: 14px;
        }
        #register:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Login</div>
                    <div class="card-body">
                        <?php if (!empty($error_message)) : ?>
                            <div class="alert alert-danger error-message" role="alert">
                                <?php echo $error_message; ?>
                            </div>
                        <?php endif; ?>
                        <form action="index.php" method="POST">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" id="username" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                            <span id="register">Register Account</span> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        //register
        document.getElementById("register").addEventListener("click", function() {
            window.location.href = "http://localhost/systemabsensi/register_user.php";
        });
    </script>
</body>
</html>
